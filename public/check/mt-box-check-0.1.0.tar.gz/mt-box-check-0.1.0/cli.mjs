#!/usr/bin/env node
/**
 * box-check CLI — run the consented, read-only capability check on THIS computer.
 *
 *   node scripts/box-check/cli.mjs [--profile cloud-ai] [--link <code from your phone> [--origin <url>]]
 *   (packaged: sh run-check.sh --link <code> — see package.sh)
 *
 * Nothing is CHECKED until the person at the computer has read the platform limits and the exact list of what will be
 * looked at, and typed "yes" (launch). Nothing leaves the computer unless a link code was given AND they type "yes" to
 * the EXACT printed report — the object reviewed is the object sent (no second check is run between review and
 * upload). Without a terminal to answer in, nothing is checked or sent. It installs nothing, changes no setting
 * and writes no file. Only these read-only commands can run: `docker --version`, `docker info --format
 * {{.ServerVersion}}`, `systemctl --user is-system-running`, `node -p <version>`.
 *
 * The upload goes to The Download's code-bound route (the-download server/routes-onboarding.ts):
 *   POST <origin>/api/onboarding/box-check/submit  { code, report, consent: true }
 * over https only (plain http is allowed to this computer's own loopback address, for a local run). A "not stored —
 * send the same report again" answer (503) or a dropped connection is retried with the SAME report; the server treats a
 * repeat as already received.
 */
import fs from 'node:fs';
import os from 'node:os';
import http from 'node:http';
import https from 'node:https';
import readline from 'node:readline/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { collectFindings, evaluate, buildReport } from './check.mjs';

export const CHECKER_VERSION = '0.1.0';
export const DEFAULT_ORIGIN = 'https://download.micro-titan.com';
export const SUBMIT_PATH = '/api/onboarding/box-check/submit';
const ALLOWED = new Set(['docker --version', 'docker info --format {{.ServerVersion}}', 'systemctl --user is-system-running', 'node -p process.versions.node.split(".")[0]']);

export function realSeams({ origin, reachDeadlineMs = 10000 } = {}) {
  return {
    platform: () => os.platform(), arch: () => os.arch(), totalMemory: () => os.totalmem(),
    freeStorage: () => { const s = fs.statfsSync(os.homedir()); return s.bavail * s.bsize; },
    osRelease: () => { try { return fs.readFileSync('/etc/os-release', 'utf8'); } catch { return null; } },
    procVersion: () => { try { return fs.readFileSync('/proc/version', 'utf8'); } catch { return null; } },
    run: async (cmd, args) => {
      if (!ALLOWED.has([cmd, ...args].join(' '))) throw new Error('command outside the read-only allowlist');
      const r = spawnSync(cmd, args, { encoding: 'utf8', timeout: 10000, stdio: ['ignore', 'pipe', 'ignore'] });
      return { code: r.status ?? -1, stdout: r.stdout, notFound: r.error?.code === 'ENOENT' };
    },
    // A bare HEAD to the upload origin: nothing about this computer is sent, no redirect is followed, and a hard
    // deadline ends the probe even if the connection stalls (a stall reads as "could not be determined").
    reach: () => new Promise((resolve) => {
      if (!origin) return resolve(null);
      const u = new URL(origin);
      let settled = false; const done = (v) => { if (!settled) { settled = true; clearTimeout(deadline); resolve(v); } };
      const req = (u.protocol === 'http:' ? http : https).request(u, { method: 'HEAD', timeout: Math.min(8000, reachDeadlineMs) }, (res) => { res.resume(); done(true); req.destroy(); });
      const deadline = setTimeout(() => { done(null); req.destroy(); }, reachDeadlineMs);
      req.on('timeout', () => { done(null); req.destroy(); });
      req.on('error', (e) => done(['ENOTFOUND', 'ECONNREFUSED', 'EHOSTUNREACH', 'ENETUNREACH'].includes(e.code) ? false : null));
      req.end();
    }),
  };
}

/** Where a report may go: https, or http only to this computer's loopback. A bare origin — no path, query or login. */
export function checkOrigin(origin) {
  let u; try { u = new URL(origin); } catch { throw new Error('the upload address is not a web address'); }
  const loopback = ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname);
  if (!(u.protocol === 'https:' || (u.protocol === 'http:' && loopback))) throw new Error('the upload address must use https');
  if (u.username || u.password || u.search || u.hash || (u.pathname !== '/' && u.pathname !== '')) throw new Error('the upload address must be a bare origin');
  return u.origin;
}

/**
 * The uploader for one origin. Sends exactly { code, report, consent: true } to that origin and NOWHERE else.
 * REDIRECTS ARE NEVER FOLLOWED (Codex review 2026-10-07: fetch's default follow replayed the report AND the claim code
 * to whatever a 307 named, and reported success): the request uses redirect "manual" and any 3xx answer is a final
 * refusal — no retry, no second request. Every attempt is bounded by `timeoutMs` (aborted, never hangs). Retries the
 * SAME bytes on 503 or a dropped/timed-out connection (the server's write is all-or-nothing and a repeat is
 * "already-received"); any other answer is final and returned as the server said it.
 */
export function makeUploader({ origin, fetchImpl = fetch, attempts = 3, timeoutMs = 15000, sleep = (ms) => new Promise((r) => setTimeout(r, ms)) }) {
  const target = new URL(SUBMIT_PATH, checkOrigin(origin));
  if (!Number.isInteger(attempts) || attempts < 1 || attempts > 5) throw new Error('attempts must be 1-5');
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 60000) throw new Error('timeoutMs must be 1-60000');
  return async ({ code, report }) => {
    const body = JSON.stringify({ code, report, consent: true });
    for (let i = 1; ; i += 1) {
      let res, json = null;
      try {
        res = await fetchImpl(target, { method: 'POST', headers: { 'content-type': 'application/json' }, body, redirect: 'manual', signal: AbortSignal.timeout(timeoutMs) });
        if (res.status >= 300 && res.status < 400 || res.type === 'opaqueredirect') {
          await res.body?.cancel?.().catch(() => {});
          return { ok: false, httpStatus: res.status, status: null, error: 'the setup service tried to send this report somewhere else — nothing was sent there; ask Micro Titan for help', attempts: i };
        }
        json = await res.json().catch(() => null);
      } catch (e) {
        if (i < attempts) { await sleep(1000 * i); continue; }
        const timedOut = e?.name === 'TimeoutError' || e?.name === 'AbortError';
        return { ok: false, httpStatus: null, error: timedOut ? 'the setup service did not answer in time — nothing was confirmed; try again' : 'could not reach the setup service — nothing was confirmed; try again', attempts: i };
      }
      if (res.status === 503 && i < attempts) { await sleep(1000 * i); continue; }
      return { ok: res.status === 200 && json?.ok === true, httpStatus: res.status, status: json?.status ?? null, error: json?.error ?? null, attempts: i };
    }
  };
}

/**
 * The whole run, with injected seams, confirmation and uploader (tests). `confirm(report)` is asked with the EXACT
 * report object that would be sent and must return true; anything else sends nothing. Returns { report, sent, upload }.
 */
export async function runCheck({ seams, profiles, profileId, answers, link, upload, confirm, now = () => new Date() }) {
  const profile = profiles.profiles[profileId];
  if (!profile) throw new Error(`unknown profile ${profileId}`);
  const findings = await collectFindings(seams, { answers });
  const evaluation = evaluate(findings, profile);
  const report = buildReport({ findings, profileId, profileVersion: profiles.version, evaluation, checkedAt: now().toISOString(), checkerVersion: CHECKER_VERSION });
  if (!(link && upload && confirm)) return { report, sent: false };
  if ((await confirm(report)) !== true) return { report, sent: false, declined: true };
  return { report, sent: true, upload: await upload({ code: link, report }) };
}

/** What this checker can say on each platform — shown BEFORE anything is checked (Codex review 2026-10-07). */
export function platformLimits(platform) {
  if (platform === 'linux') return 'This computer runs Linux (including Windows with WSL2). The assistant is supported here, subject to what the check finds.';
  if (platform === 'win32') return 'This computer runs Windows. The assistant runs inside WSL2 (a Linux layer for Windows); without it the check can only say what to prepare.';
  if (platform === 'darwin') return 'This computer runs macOS. The assistant does not support macOS yet, so the check can only report that — it cannot say Ready.';
  return 'This operating system is not supported by the assistant; the check can only report that.';
}
/** Exactly what the probes look at — the list the person agrees to. */
export const CHECK_LIST = [
  'Operating system, its version, and whether it is WSL',
  'Processor type',
  'Total memory and free storage space',
  'Whether Docker, a systemd user session and Node.js are present, and Node.js\'s version',
  'Whether this computer can reach the setup service (one connection test; nothing about this computer is sent)',
];

/**
 * The interactive run. `io` = { isTTY, write(text), ask(question) → answer }. Order (Codex review 2026-10-07):
 *   1. platform limits + exactly what will be looked at; 2. a typed "yes" BEFORE ANY PROBE (no terminal → nothing is
 *   checked); 3. the one question; 4. the probes; 5. the exact report; 6. a second typed "yes" before any upload.
 * Returns { checked, sent, report?, upload? }. Never installs or changes anything.
 */
export async function launch({ io, platform, profiles, profileId = 'cloud-ai', link, origin, makeSeams, makeUpload, now }) {
  const say = (s) => io.write(`${s}\n`);
  say('Micro Titan computer check — it only looks. It installs nothing, changes no setting and reads no personal files or passwords.');
  say(''); say(platformLimits(platform)); say(''); say('With your permission it will look at:');
  for (const item of CHECK_LIST) say(`  • ${item}`);
  say('You will see the exact results before anything is added to your setup.');
  if (!io.isTTY) { say('Nothing was checked: this needs a person at this computer to type yes.'); return { checked: false, sent: false }; }
  if ((await io.ask('Type yes to run this check: ')).trim().toLowerCase() !== 'yes') { say('Nothing was checked.'); return { checked: false, sent: false }; }
  const av = (await io.ask('Can this computer stay on and awake during the hours you need reminders? (yes / no / skip): ')).trim().toLowerCase();
  const answers = { availableDuringReminderHours: av === 'yes' || av === 'no' ? av : undefined };
  const confirm = link ? async (report) => {
    say(JSON.stringify(report, null, 2)); say(''); say('This is everything that would be added to your setup — nothing else about this computer is sent.');
    return (await io.ask('Type yes to add this exact report to your setup: ')).trim().toLowerCase() === 'yes';
  } : null;
  const r = await runCheck({ seams: makeSeams({ origin }), profiles, profileId, answers, link, upload: link ? makeUpload({ origin }) : null, confirm, now });
  if (!link) { say(JSON.stringify(r.report, null, 2)); say(''); say('Nothing was sent. To add this check to your setup, run it again with the code from your phone.'); }
  else if (!r.sent) say('Nothing was sent.');
  else if (r.upload.ok) say(r.upload.status === 'already-received' ? 'Already added to your setup.' : 'Added to your setup.');
  else say(`Not added: ${r.upload.error ?? `the setup service answered ${r.upload.httpStatus}`}`);
  return { checked: true, ...r };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const a = process.argv.slice(2); const arg = (n) => { const i = a.indexOf(`--${n}`); return i >= 0 ? a[i + 1] : undefined; };
  const profiles = JSON.parse(fs.readFileSync(path.join(path.dirname(fileURLToPath(import.meta.url)), 'profiles.json'), 'utf8'));
  const link = arg('link');
  const origin = link ? checkOrigin(arg('origin') ?? DEFAULT_ORIGIN) : undefined;
  const rl = process.stdin.isTTY ? readline.createInterface({ input: process.stdin, output: process.stdout }) : null;
  const io = { isTTY: Boolean(process.stdin.isTTY), write: (s) => process.stdout.write(s), ask: (q) => rl.question(q) };
  try {
    const r = await launch({ io, platform: os.platform(), profiles, profileId: arg('profile') ?? 'cloud-ai', link, origin, makeSeams: realSeams, makeUpload: makeUploader });
    if (r.sent && !r.upload.ok) process.exitCode = 1;
  } finally { rl?.close(); }
}
