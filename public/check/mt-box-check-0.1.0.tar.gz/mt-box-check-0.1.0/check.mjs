/**
 * box-check — the CONSENTED, READ-ONLY capability check for a customer's own computer (owner-approved
 * compatibility-first onboarding, 2026-10-07). Behaviour reference: Codex's preview (consent → check → review → add to
 * intake; outcomes Ready / Needs preparation / Dedicated box recommended / Check incomplete).
 *
 * collectFindings(seams) — observes only. It installs nothing, changes no setting and writes no file. It collects a
 *   fixed allowlist: OS family (+ Linux distribution id/version, WSL yes/no), CPU architecture, total memory, free
 *   storage where the assistant would live, presence/version of the prerequisites, whether the required services are
 *   reachable, and one customer answer (availability during reminder hours). Every probe that fails is UNKNOWN, never
 *   a pass. No hostname, user name, path, serial, MAC/IP address, file name or credential is collected.
 * evaluate(findings, profile) — the outcome. Ready only when EVERY requirement is measured AND every finding is
 *   known AND all pass. Precedence: Dedicated box recommended > Needs preparation > Check incomplete > Ready.
 * buildReport / assertAllowlisted — the exact object the customer reviews and consents to upload; anything outside
 *   the allowlist, or any string that looks personal or identifying, is refused.
 */
import crypto from 'node:crypto';

export const FINDING_KEYS = ['os.platform', 'os.distroId', 'os.distroVersion', 'os.wsl', 'cpu.arch', 'memory.totalBytes', 'storage.freeBytes',
  'prereq.docker', 'prereq.dockerDaemon', 'prereq.systemdUser', 'prereq.nodeMajor', 'network.requiredReachable', 'gpu.present', 'answers.availableDuringReminderHours'];
const ENUMS = { 'os.platform': ['linux', 'darwin', 'win32', 'other'], 'cpu.arch': ['x64', 'arm64', 'other'] };
const known = (value) => ({ status: 'measured', value });
const unknown = (why) => ({ status: 'unknown', value: null, why });

/** Run every probe through injected, read-only seams; any failure becomes `unknown` with its reason. */
export async function collectFindings(seams, { answers = {} } = {}) {
  const f = {};
  const tryProbe = async (key, fn) => { try { f[key] = await fn(); } catch (e) { f[key] = unknown(`probe failed (${String(e?.message ?? e).slice(0, 60)})`); } };
  await tryProbe('os.platform', async () => { const p = seams.platform(); return known(ENUMS['os.platform'].includes(p) ? p : 'other'); });
  await tryProbe('cpu.arch', async () => { const a = seams.arch(); return known(ENUMS['cpu.arch'].includes(a) ? a : 'other'); });
  const linux = f['os.platform'].value === 'linux';
  await tryProbe('os.distroId', async () => { if (!linux) return known(null); const r = seams.osRelease(); const m = /^ID=("?)([a-z0-9._-]{1,32})\1$/m.exec(r ?? ''); return m ? known(m[2]) : unknown('no distribution id'); });
  await tryProbe('os.distroVersion', async () => { if (!linux) return known(null); const r = seams.osRelease(); const m = /^VERSION_ID=("?)([0-9][0-9.]{0,15})\1$/m.exec(r ?? ''); return m ? known(m[2]) : unknown('no distribution version'); });
  await tryProbe('os.wsl', async () => { if (!linux) return known(false); const v = seams.procVersion(); return v == null ? unknown('kernel version unreadable') : known(/microsoft/i.test(v)); });
  await tryProbe('memory.totalBytes', async () => { const n = seams.totalMemory(); return Number.isFinite(n) && n > 0 ? known(Math.floor(n)) : unknown('memory size unreadable'); });
  await tryProbe('storage.freeBytes', async () => { const n = seams.freeStorage(); return Number.isFinite(n) && n >= 0 ? known(Math.floor(n)) : unknown('free storage unreadable'); });
  await tryProbe('prereq.docker', async () => { const r = await seams.run('docker', ['--version']); return r.code === 0 ? known(true) : r.code === 127 || r.notFound ? known(false) : unknown(`docker --version exit ${r.code}`); });
  await tryProbe('prereq.dockerDaemon', async () => { if (f['prereq.docker'].value !== true) return known(false); const r = await seams.run('docker', ['info', '--format', '{{.ServerVersion}}']); return r.code === 0 ? known(true) : unknown(`the container daemon did not answer (exit ${r.code})`); });
  await tryProbe('prereq.systemdUser', async () => { if (!linux) return known(null); const r = await seams.run('systemctl', ['--user', 'is-system-running']); const w = String(r.stdout ?? '').trim(); return ['running', 'degraded'].includes(w) ? known(true) : r.notFound || w === 'offline' ? known(false) : unknown(`systemd user manager state "${w || 'none'}"`); });
  await tryProbe('prereq.nodeMajor', async () => { const r = await seams.run('node', ['-p', 'process.versions.node.split(".")[0]']); if (r.notFound || r.code === 127) return known(0); const n = Number(String(r.stdout ?? '').trim()); return r.code === 0 && Number.isInteger(n) ? known(n) : unknown('node version unreadable'); });
  await tryProbe('network.requiredReachable', async () => { const r = await seams.reach(); return r === true || r === false ? known(r) : unknown('reachability could not be determined'); });
  await tryProbe('gpu.present', async () => unknown('not probed: no local-model requirement is measured'));
  const a = answers.availableDuringReminderHours;
  f['answers.availableDuringReminderHours'] = a === 'yes' || a === 'no' ? known(a) : unknown('not answered');
  return f;
}

/** Evaluate findings against one profile. Never Ready on anything missing, unknown or unmeasured. */
export function evaluate(findings, profile) {
  const dedicated = []; const prepare = []; const incomplete = []; const passed = [];
  const val = (k) => findings[k];
  const platform = val('os.platform')?.value;
  for (const r of profile.requirements) {
    if (r.onlyFor && !r.onlyFor.includes(platform)) continue;
    if (r.provenance?.status === 'unmeasured' || (['min', 'max'].includes(r.rule) && r.value == null)) { incomplete.push(`${r.id}: requirement not measured yet`); continue; }
    const fnd = val(r.finding);
    if (!fnd || fnd.status !== 'measured') { incomplete.push(`${r.id}: ${fnd?.why ?? 'not checked'}`); continue; }
    const v = fnd.value;
    if (r.rule === 'platform-support') {
      if (r.supported.includes(v)) passed.push(r.id);
      else if (r.preparable?.[v]) prepare.push(`${r.id}: ${r.preparable[v]}`);
      else if (r.notYetSupported?.includes(v)) incomplete.push(`${r.id}: this operating system is not supported by the assistant yet`);
      else incomplete.push(`${r.id}: unrecognised operating system`);
    } else if (r.rule === 'in') {
      if (r.values.includes(v)) passed.push(r.id);
      else if (r.unknownFor?.includes(v)) incomplete.push(`${r.id}: ${r.unknownWhy}`);
      else incomplete.push(`${r.id}: unrecognised value`);
    } else if (r.rule === 'present' || r.rule === 'true') {
      if (v === true) passed.push(r.id); else if (v === false) prepare.push(`${r.id}: ${r.fix}`); else incomplete.push(`${r.id}: not determined`);
    } else if (r.rule === 'min') {
      if (typeof v === 'number' && v >= r.value) passed.push(r.id); else if (typeof v === 'number') prepare.push(`${r.id}: ${r.fix ?? 'below the measured requirement'}`); else incomplete.push(`${r.id}: not determined`);
    } else if (r.rule === 'answer-yes') {
      if (v === 'yes') passed.push(r.id); else if (v === 'no') dedicated.push(`${r.id}: ${r.dedicatedIfNo}`); else incomplete.push(`${r.id}: not answered`);
    } else incomplete.push(`${r.id}: unknown rule`);
  }
  if (platform === 'linux') {
    const d = val('prereq.dockerDaemon');
    if (val('prereq.docker')?.value === true && d?.status !== 'measured') incomplete.push('docker: the container daemon did not answer');
  }
  const outcome = dedicated.length ? 'dedicated-box-recommended' : prepare.length ? 'needs-preparation' : incomplete.length ? 'check-incomplete' : 'ready';
  return { outcome, dedicated, prepare, incomplete, passed };
}

const PERSONAL = [/\b\d{1,3}(\.\d{1,3}){3}\b/, /\b([0-9a-f]{2}:){5}[0-9a-f]{2}\b/i, /[\w.+-]+@[\w-]+\.[\w.]+/, /(^|\/)(home|Users)\//, /[A-Za-z]:\\/];
export const REPORT_SCHEMA = 'mt-box-check-report/v1';
export const OUTCOMES = ['ready', 'needs-preparation', 'dedicated-box-recommended', 'check-incomplete'];
export const PROFILE_IDS = ['cloud-ai', 'local-models'];
/** The exact type of every finding's value when measured (null is also allowed where noted). */
const VALUE_TYPES = {
  'os.platform': { enum: ENUMS['os.platform'] }, 'os.distroId': { pattern: /^[a-z0-9._-]{1,32}$/, nullable: true },
  'os.distroVersion': { pattern: /^[0-9][0-9.]{0,15}$/, nullable: true }, 'os.wsl': { type: 'boolean' }, 'cpu.arch': { enum: ENUMS['cpu.arch'] },
  'memory.totalBytes': { type: 'integer' }, 'storage.freeBytes': { type: 'integer' }, 'prereq.docker': { type: 'boolean' },
  'prereq.dockerDaemon': { type: 'boolean' }, 'prereq.systemdUser': { type: 'boolean', nullable: true }, 'prereq.nodeMajor': { type: 'integer' },
  'network.requiredReachable': { type: 'boolean' }, 'gpu.present': { type: 'boolean' }, 'answers.availableDuringReminderHours': { enum: ['yes', 'no'] },
};
const exactKeys = (o, keys, where) => {
  if (!o || typeof o !== 'object' || Array.isArray(o)) throw new Error(`${where} must be an object`);
  const extra = Object.keys(o).filter((k) => !keys.includes(k)); const missing = keys.filter((k) => !(k in o));
  if (extra.length) throw new Error(`${where} has fields outside the allowlist: ${extra.join(', ')}`);
  if (missing.length) throw new Error(`${where} is missing: ${missing.join(', ')}`);
};
const shortText = (v, where, max) => { if (typeof v !== 'string' || v.length === 0 || v.length > max || /[\u0000-\u001f]/.test(v)) throw new Error(`${where} is not a short single-line text`); for (const re of PERSONAL) if (re.test(v)) throw new Error('the report contains a personal or identifying string'); };

/** The exact upload object. */
export function buildReport({ findings, profileId, profileVersion, evaluation, checkedAt, checkerVersion }) {
  const report = { schema: REPORT_SCHEMA, checkerVersion, profileId, profileVersion, checkedAt, outcome: evaluation.outcome,
    reasons: { dedicated: [...evaluation.dedicated], prepare: [...evaluation.prepare], incomplete: [...evaluation.incomplete] },
    findings: Object.fromEntries(FINDING_KEYS.map((k) => {
      const f = findings[k] ?? unknown('not checked');
      return [k, f.status === 'measured' ? { status: 'measured', value: f.value } : { status: 'unknown', value: null, why: f.why ?? 'not determined' }];
    })) };
  assertAllowlisted(report);
  return report;
}
/**
 * STRICT, RECURSIVE validation of the exact report (Codex review 2026-10-07: nested payloads slipped through). Every
 * level has an exact key set; every value has an exact type; enums are enforced; reason strings are bounded
 * "<requirement id>: <text>" lines; nothing personal-looking anywhere.
 */
export function assertAllowlisted(report) {
  exactKeys(report, ['schema', 'checkerVersion', 'profileId', 'profileVersion', 'checkedAt', 'outcome', 'reasons', 'findings'], 'report');
  if (report.schema !== REPORT_SCHEMA) throw new Error('unknown report schema');
  if (typeof report.checkerVersion !== 'string' || !/^\d+\.\d+\.\d+$/.test(report.checkerVersion)) throw new Error('checkerVersion must be x.y.z');
  if (!PROFILE_IDS.includes(report.profileId)) throw new Error('unknown profileId');
  if (typeof report.profileVersion !== 'string' || !/^\d{4}-\d{2}-\d{2}\.\d{1,3}$/.test(report.profileVersion)) throw new Error('profileVersion must be YYYY-MM-DD.n');
  if (typeof report.checkedAt !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/.test(report.checkedAt) || Number.isNaN(Date.parse(report.checkedAt))) throw new Error('checkedAt must be an ISO UTC time');
  if (!OUTCOMES.includes(report.outcome)) throw new Error('unknown outcome');
  exactKeys(report.reasons, ['dedicated', 'prepare', 'incomplete'], 'reasons');
  for (const [k, list] of Object.entries(report.reasons)) {
    if (!Array.isArray(list) || list.length > 20) throw new Error(`reasons.${k} must be a short list`);
    for (const line of list) { shortText(line, `reasons.${k}`, 200); if (!/^[a-z][a-z-]{0,30}: /.test(line)) throw new Error(`reasons.${k} entries must read "<requirement>: <text>"`); }
  }
  exactKeys(report.findings, FINDING_KEYS, 'findings');
  for (const k of FINDING_KEYS) {
    const f = report.findings[k];
    if (f && f.status === 'unknown') {
      exactKeys(f, ['status', 'value', 'why'], `finding ${k}`);
      if (f.value !== null) throw new Error(`finding ${k}: an unknown finding has no value`);
      shortText(f.why, `finding ${k}.why`, 120);
      continue;
    }
    exactKeys(f, ['status', 'value'], `finding ${k}`);
    if (f.status !== 'measured') throw new Error(`finding ${k}: status must be measured or unknown`);
    const t = VALUE_TYPES[k]; const v = f.value;
    if (v === null) { if (!t.nullable) throw new Error(`finding ${k}: value is required`); continue; }
    if (t.enum && !t.enum.includes(v)) throw new Error(`finding ${k}: value outside its enum`);
    if (t.type === 'boolean' && typeof v !== 'boolean') throw new Error(`finding ${k}: must be true or false`);
    if (t.type === 'integer' && !(Number.isSafeInteger(v) && v >= 0)) throw new Error(`finding ${k}: must be a non-negative integer`);
    if (t.pattern && !(typeof v === 'string' && t.pattern.test(v))) throw new Error(`finding ${k}: value has the wrong form`);
  }
  // Belt and braces: no personal-looking string anywhere in the serialised report.
  for (const str of JSON.stringify(report).match(/"(?:[^"\\]|\\.)*"/g) ?? []) for (const re of PERSONAL) if (re.test(JSON.parse(str))) throw new Error('the report contains a personal or identifying string');
  return true;
}
export const reportId = (report) => crypto.createHash('sha256').update(JSON.stringify(report)).digest('hex');
