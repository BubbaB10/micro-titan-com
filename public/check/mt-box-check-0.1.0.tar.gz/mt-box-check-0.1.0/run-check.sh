#!/bin/sh
# Micro Titan computer check — launcher (Linux, including Windows with WSL2).
#
#   sh run-check.sh                       check this computer and show the result (nothing is sent)
#   sh run-check.sh --link <code>         ... and offer to add the exact result to your setup
#
# It INSTALLS NOTHING. Before running anything it confirms its own files against SHA256SUMS, and that Node.js 18 or
# newer is already on this computer (the checker is a Node.js program; it never installs Node.js or anything else).
# The checker then shows what it can say on this platform and exactly what it will look at, and asks you to type yes
# before it looks at anything.
set -u
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)

if command -v sha256sum >/dev/null 2>&1; then SUMCHECK="sha256sum -c --strict --quiet SHA256SUMS"
elif command -v shasum >/dev/null 2>&1; then SUMCHECK="shasum -a 256 -c --strict --quiet SHA256SUMS"
else echo "This computer has no checksum tool, so the checker cannot confirm its own files. Nothing was checked."; exit 4; fi
if ! (cd "$HERE" && $SUMCHECK) >/dev/null 2>&1; then
  echo "This checker's files do not match their checksums — the copy may be damaged or altered. Nothing was checked."
  echo "Please get a fresh copy from Micro Titan."
  exit 4
fi

NODE=$(command -v node 2>/dev/null || true)
if [ -z "$NODE" ]; then
  echo "This checker needs Node.js 18 or newer to run, and Node.js is not installed on this computer."
  echo "The checker does not install it. Nothing was checked or sent. Your Micro Titan contact can help with the next step."
  exit 3
fi
MAJOR=$("$NODE" -p 'process.versions.node.split(".")[0]' 2>/dev/null || echo 0)
case "$MAJOR" in ''|*[!0-9]*) MAJOR=0 ;; esac
if [ "$MAJOR" -lt 18 ]; then
  echo "This checker needs Node.js 18 or newer to run; this computer has Node.js $MAJOR."
  echo "The checker does not upgrade it. Nothing was checked or sent. Your Micro Titan contact can help with the next step."
  exit 3
fi

exec "$NODE" "$HERE/cli.mjs" "$@"
