Micro Titan computer check 0.1.0

What it does: looks at this computer — operating system, processor, memory, free storage, whether Docker, a systemd
user session and Node.js are present — to see whether a Micro Titan assistant can run here. It installs nothing,
changes no setting and reads no personal files or passwords. It asks you to type yes before it looks, and again
before anything is added to your setup.

Supported: Linux, including Windows with WSL2 (run it inside your WSL2 Linux). On macOS it can only report that macOS
is not supported yet. It needs Node.js 18 or newer already installed; it will not install it.

How to run, in a terminal in this folder:
  sh run-check.sh --link <the code shown on your phone>

Without --link it shows the result and sends nothing.
